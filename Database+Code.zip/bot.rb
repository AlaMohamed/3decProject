require 'sinatra' # Import af libraries 
require 'json' 
require 'sqlite3'

set :port, 6000 # Lytter til porten

before do 
  @params = JSON.parse(request.body.read) 
end 
 
post '/' do 
  content_type :json 
  puts @params
  if @params['action']['slug'] == 'bookingroom' # kig på cancel room --> altså else-if
    roombooking = "The room " + @params['roomnumber']['raw'] + " has been booked"
  end 
  { 
    replies: [{ type: 'text', content: roombooking }], 
    conversation: { 
      memory: { 
        key: 'value' 
      }
    } 
  }.to_json 
end 

post '/bookingroom' do
  puts @params
    roomnumber = @params['conversation']['memory']['roomnumber']['value']
    buildingnumber = roomnumber.split(".") # Splitter det op i et array 
    buildingexist = true
    responsetext = ""

    # ALL THESE CHECKS IF THE BUILDING EXIST
    begin
      db = SQLite3::Database.open "ProjectDB.db"
      stm = db.prepare "SELECT COUNT (building_id) FROM BUILDING WHERE building_number = '#{buildingnumber[0]}'" 
      rs = stm.execute 
      buildingcount = rs.next

      if (buildingcount[0] == 0) then 
        puts "doesnt exist" 
        buildingexist = false
      end
  
    rescue SQLite3::Exception => e 
      puts "Exception occurred"
      puts e
    ensure
      stm.close if stm
      db.close if db
    end

    if (buildingexist == true) then 
      responsetext = "The room exist! \nWhen do you want to book the room? Please give me a specific date"
    
    elsif 
      responsetext == "The building does not exist. Try another building and room"
    end
    
    content_type :json 
    { 
      replies: [{ type: 'text', content: responsetext }], 
      conversation: { 
        memory: { 
          'roomnumber': roomnumber 
        } 
      } 
    }.to_json 
  end

  #TILFØJET
  post '/bookingagreement' do
    puts @params 
      bookingdate = @params['conversation']['memory']['date']['raw']
      #bookingdate = "13-12-2019"
      #userroomnumber = "27.1-001"
      userroomnumber = @params['conversation']['memory']['roomnumber']
      roomnumber = userroomnumber.split(".")
      #puts roomnumber[1] for at se splittelse
      bookingConfirmed = true
      bookingResponse = ""

    begin
       db = SQLite3::Database.open "ProjectDB.db"
       sqlJoin = "SELECT room_id FROM ROOMS INNER JOIN BUILDING ON building.building_id = rooms.building_id WHERE building.building_number = '#{roomnumber[0]}' AND rooms.room_number = '#{roomnumber[1]}'"

       stm = db.prepare(sqlJoin) 
       rs = stm.execute()
       room_id = rs.next
       puts room_id[0]
=begin
       if (room_id[0] == 0) then 
        puts "doesnt exist" 
        bookingConfirmed = false
      end
=end
       strSql = "INSERT INTO BOOKING (room_id, date) VALUES ('#{room_id[0]}', '#{bookingdate}')" ## konverteret til en string v.b.a {}
       puts strSql 
       stm = db.prepare(strSql) 
       stm.execute()
       puts "BOOKING OPRETTET"

    rescue SQLite3::Exception => e 
      puts "Exception occurred"
      puts e
    ensure
      stm.close if stm
      db.close if db
    end
=begin 
    if (bookingConfirmed == true) then 
      bookingResponse = "Your booking is confirmed! \n Your bookingID is #{bookingID} for your reservation"
      # lav en her som sender bookingID ud til brugeren 
    elsif 
      bookingResponse == "Your booking is not confirmed. Try a new date"
    end
=end
      content_type :json 
      { 
        replies: [{ type: 'text', content: 'Your Booking is confirmed! Have a nice day :)' }], #1 We need to change the content so we get a  booking_id as agreement for the booking?
        conversation: { 
          memory: { 
            key: 'value'  #2 maybe change this to fix #1 
          } 
        } 
      }.to_json 
    end
  

post '/cancelBooking' do 
  puts @params 
  bookingID = @params['conversation']['memory']['date']['raw'] # <-- forkert. room_id skal bruges i stedet # er sikker på det kan virke med bookingID 
  cancelresponstext = ""
  bookingGone = true
 
  begin
    db = SQLite3::Database.open "ProjectDB.db"
    bookingdelete = "DELETE FROM BOOKING WHERE booking_id = #{bookingID}" # måske ;
    stm = db.prepare(bookingdelete)
    rs = stm.execute 
    bookingCancelled = rs.next

=begin
    if (bookingCancelled[0] == 0) then 
     puts "doesnt exist" 
     bookingGone = false
   end
=end

  rescue SQLite3::Exception => e 
    puts "Exception occurred"
    puts e
  ensure
    stm.close if stm
    db.close if db
  end

    if (bookingGone == true) then 
      cancelresponstext = "You have now cancelled your booking!"
    elsif 
      cancelresponstext = "The booking is not completed, try again please"
  end

  content_type :json 
      { 
        replies: [{ type: 'text', content: cancelresponstext }], #1 We need to change the content so we get a  booking_id as agreement for the booking?
        conversation: { 
          memory: { 
            key: 'value'  #2 maybe change this to fix #1 
          } 
        } 
      }.to_json 
end

post '/modifyBooking' do
  puts @params

=begin
  updRoom = @params 
  #updDate = @params
  
  begin
    db = SQLite3::Database.open "ChatbotnewDB.db"
    updSql = "UPDATE BOOKING SET room_id = #{updRoom} OR date = #{updDate} WHERE booking_id = #{bookingID}" # mangler bookingID 
    stm = db.prepare(updSql)
    rs = stm.execute 
# 1. Hvis room ændres, så skal vi finde ud af om bygningen eksistere, hvis ja --> 2. skal vi finde ud af om room eksistere, 3. room er ledigt
# 2. Hvis #1 opfyldes skal vi derefter update room_id i db, og sende samme bookingID tilbage

  rescue SQLite3::Exception => e 
    puts "Exception occurred"
    puts e
  ensure
    stm.close if stm
    db.close if db
  end
=end

content_type :json 
{ 
  replies: [{ type: 'text', content: 'Give me your bookingID' }], #1 We need to change the content so we get a  booking_id as agreement for the booking?
  conversation: { 
    memory: { 
      key: 'value'  #2 maybe change this to fix #1 
    } 
  } 
}.to_json 
end 

post '/errors' do 
  puts @params 
  200 
end

post '/testdb' do
  begin
    db = SQLite3::Database.open "Chatbot.db"
    stm = db.prepare "SELECT * FROM BUILDING"
    rs = stm.execute 

    rs.each do |row|
      puts row.join "\s"
    end
  rescue SQLite3::Exception => e 
    puts "Exception occurred"
    puts e
  ensure
    stm.close if stm
    db.close if db
  end
  
  200
end